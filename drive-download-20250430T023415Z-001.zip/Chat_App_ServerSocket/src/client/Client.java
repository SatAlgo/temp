

package client;


import java.io.*;
import java.net.*;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		Socket s = new Socket("localhost", 9000);
		System.out.println("Connetced ! ");
		
		DataInputStream din = new DataInputStream(s.getInputStream());
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		String Cmsg = "" , Smsg = "";
		
		while(!Cmsg.equals("stop")) {
			
			System.out.print("Client : ");
			Cmsg = br.readLine();
			dout.writeUTF(Cmsg);
//			System.out.println("Msg Sent To Server ! ");
			
			dout.flush();
			
			Smsg = din.readUTF();
			System.out.println("Server Says : "+ Smsg);		
		}
		
		din.close();
		
		dout.close();
		br.close();
		s.close();
		
		System.out.println("chat Ended ");
		
	}
	
}
