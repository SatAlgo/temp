package server;

import java.io.*;
import java.net.*;

public class Server {
	
	public static void main(String[] args) throws IOException {
		
		ServerSocket ss = new ServerSocket(9000);
		System.out.println("Server is Staarted on Port 9000");
		
		Socket s = ss.accept();
		System.out.println("Client Connected ! ");
		
		DataInputStream din = new DataInputStream(s.getInputStream());
		DataOutputStream dout = new DataOutputStream(s.getOutputStream());
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		  
		String Cmsg = "", Smsg = "";
		
		while(!Cmsg.equals("stop")) {
			
			Cmsg = din.readUTF();
			System.out.println("Client Says : " + Cmsg);
			
			System.out.print("Server : ");
			Smsg = br.readLine();
			dout.writeUTF(Smsg);
			
			dout.flush();
		}
		
		din.close();
		dout.close();
		s.close();
		ss.close();
		System.out.println("Chat Ended ");
	}
	
}
