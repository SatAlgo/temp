package client;

import java.util.*;
import java.io.IOException;
import java.net.*;

public class Client {

	public static void main(String[] args) throws IOException {
		Scanner sc= new Scanner(System.in);
		
		
		DatagramSocket cds = new DatagramSocket();
		
		byte Cbuffer[] = new byte[1024];
		
		InetAddress Sip = InetAddress.getByName("localhost");
		int Sport = 8080;
		
		while(true) {
			
			System.out.println("Client : ");
			String Cmsg = sc.next();
			
			byte[] Sendbuffer = Cmsg.getBytes();
			
			DatagramPacket Cdp = new DatagramPacket(Sendbuffer, Sendbuffer.length , Sip , Sport);
			
			cds.send(Cdp);
			
			if(Cmsg.equals("stop")) {
				System.out.println("stop");
				break;
			}
			
			
			DatagramPacket recMsg = new DatagramPacket(Cbuffer, Cbuffer.length);
			cds.receive(recMsg);
			
			String ServMsg = new String(recMsg.getData() , 0 , recMsg.getLength());
			
			System.out.println("Server Says : " + ServMsg);
			
			if(ServMsg.equals("stop")) {
				System.out.println("Eiting !!!!!!");
				break;
			}
			
		}
		
		cds.close();
		sc.close();
		
	}
}
