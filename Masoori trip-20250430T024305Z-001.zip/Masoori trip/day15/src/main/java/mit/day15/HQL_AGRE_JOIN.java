package mit.day15;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.Transaction;
import java.util.*;

public class HQL_AGRE_JOIN {
    
    public static void main(String[] args) {
        // Step 1: Setting up the Hibernate configuration and session factory
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory fac = md.getSessionFactoryBuilder().build();
        
        // Step 2: Opening a session and beginning a transaction
        Session sec = fac.openSession();
        Transaction t = sec.beginTransaction();
        
        try {
            // ********* AGGREGATIONS ************

            // 1) SUM
            String query1 = "select sum(id) from Employee"; // Sum of IDs
            Query q1 = sec.createQuery(query1);
            long sumID = (Long) q1.uniqueResult();
            System.out.println("Sum of IDs: " + sumID);

            // 2) AVG (Average)
            String query2 = "select avg(id) from Employee"; // Average of IDs
            Query q2 = sec.createQuery(query2);
            double avgID = (Double) q2.uniqueResult();
            System.out.println("Average of IDs: " + avgID);

            // 3) MIN & MAX (Minimum & Maximum)
            String query3 = "select min(id) from Employee"; // Minimum ID
            String query4 = "select max(id) from Employee"; // Maximum ID
            Query q3 = sec.createQuery(query3);
            Query q4 = sec.createQuery(query4);

            int minID = (Integer) q3.uniqueResult();
            int maxID = (Integer) q4.uniqueResult();
            System.out.println("Minimum ID: " + minID + " And Maximum ID: " + maxID);

            // Committing the transaction after successful execution
            t.commit();

        } catch (Exception e) {
            // Rolling back in case of error
            if (t != null) {
                t.rollback();
            }
            e.printStackTrace();
        } finally {
            // Closing session and session factory to release resources
            sec.close();
            fac.close();
        }
    }
}
