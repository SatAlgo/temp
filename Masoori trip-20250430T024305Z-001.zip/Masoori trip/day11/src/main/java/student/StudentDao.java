package student;

import java.sql.*;
import java.util.*;

public class StudentDao {
    static Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/studentdb", "root", "Pratik@3690");
    }

    public static int save(Student s) throws Exception {
        Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement("INSERT INTO student(name,email,course) VALUES(?,?,?)");
        ps.setString(1, s.getName());
        ps.setString(2, s.getEmail());
        ps.setString(3, s.getCourse());
        return ps.executeUpdate();
    }

    public static List<Student> getAll() throws Exception {
        Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM student");
        ResultSet rs = ps.executeQuery();

        List<Student> list = new ArrayList<>();
        while (rs.next()) {
            Student s = new Student();
            s.setId(rs.getInt(1));
            s.setName(rs.getString(2));
            s.setEmail(rs.getString(3));
            s.setCourse(rs.getString(4));
            list.add(s);
        }
        return list;
    }

    public static int delete(int id) throws Exception {
        Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement("DELETE FROM student WHERE id=?");
        ps.setInt(1, id);
        return ps.executeUpdate();
    }

    public static Student getById(int id) throws Exception {
        Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM student WHERE id=?");
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        Student s = new Student();
        if (rs.next()) {
            s.setId(rs.getInt(1));
            s.setName(rs.getString(2));
            s.setEmail(rs.getString(3));
            s.setCourse(rs.getString(4));
        }
        return s;
    }

    public static int update(Student s) throws Exception {
        Connection con = getConnection();
        PreparedStatement ps = con.prepareStatement("UPDATE student SET name=?, email=?, course=? WHERE id=?");
        ps.setString(1, s.getName());
        ps.setString(2, s.getEmail());
        ps.setString(3, s.getCourse());
        ps.setInt(4, s.getId());
        return ps.executeUpdate();
    }
}