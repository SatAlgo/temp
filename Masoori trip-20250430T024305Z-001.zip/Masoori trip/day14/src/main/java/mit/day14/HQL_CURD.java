package mit.day14;

import org.hibernate.*;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.query.Query;
import org.hibernate.Transaction;

import java.util.*;

public class HQL_CURD {

    public static void main(String[] args) {
        
        // Step 1: Setting up the Hibernate configuration and session factory
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata md = new MetadataSources(ssr).getMetadataBuilder().build();
        SessionFactory fac = md.getSessionFactoryBuilder().build();
        
        // Step 2: Opening a session and beginning a transaction
        Session sec = fac.openSession();
        Transaction t = sec.beginTransaction();
        
        try {
            // ********** READ ************
            String query1 = "from mit.day14.Employee as e where e.id = :empId";
            Query q1 = sec.createQuery(query1);
            q1.setParameter("empId", 1004);  // Example: Use an existing ID in your database
            
            List<Employee> list = q1.list();
            
            for(Employee e : list) {
                System.out.println("ID : " + e.getId());
                System.out.println("Fname : " + e.getFirstname());
                System.out.println("Lname : " + e.getLastname());
            }
            
            // ************* UPDATE ***********
            String query2 = "Update Employee as e set e.firstname = :newFirstName where e.id = :empId";
            Query q2 = sec.createQuery(query2);
            q2.setParameter("newFirstName", "Rahul Updated");  // New first name
            q2.setParameter("empId", 1004);  // ID of the employee to update
            
            int r1 = q2.executeUpdate();
            
            // ************* DELETE ****************
            String query3 = "delete from Employee as e where e.id = :empId";
            Query q3 = sec.createQuery(query3);
            q3.setParameter("empId", 1004);  // ID of the employee to delete
            int r2 = q3.executeUpdate();
            
            // Commit transaction after executing all queries
            t.commit();
            
            System.out.println("Number of Records Updated : " + r1);
            System.out.println("Number of Records Deleted : " + r2);
            
        } catch (Exception e) {
            // If there is an exception, roll back the transaction
            if (t != null) {
                t.rollback();
            }
            e.printStackTrace();
        } finally {
            // Close session and factory to release resources
            sec.close();
            fac.close();
        }
    }
}
