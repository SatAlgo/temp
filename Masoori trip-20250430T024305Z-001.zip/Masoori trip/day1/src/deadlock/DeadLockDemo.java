package deadlock;

public class DeadLockDemo {

	public static void main(String[] args) {
		
		String houseKey = "House Key";
		String carKey = "Car Key";
		
		Thread person1 = new Thread( () -> {
			
			synchronized(houseKey){
				System.out.println("Person 1 Got the House Keys ! Now i want car keys Waiting for person2 ....");
				synchronized (carKey){  
					System.out.println("Person 1 Got the car Keys !");
				}	
			}
		});
	
		Thread person2 = new Thread( () -> {
			
			synchronized (carKey) {
				System.out.println("Person 2 Got the Car Keys ! Now i want House keys Waiting for person1 ....");
				
				synchronized (houseKey) {
					System.out.println("Person 2 Got House Keys ");
				}	
			}
		});
		
		person1.start();
		person2.start();
		
	}
}
