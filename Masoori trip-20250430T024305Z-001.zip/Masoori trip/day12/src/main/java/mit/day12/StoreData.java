package mit.day12;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import java.io.IOException;

public class StoreData {
    public static void main(String[] args) throws IOException {

        // Setup Hibernate session
        StandardServiceRegistry ssr = new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();
        Metadata meta = new MetadataSources(ssr).getMetadataBuilder().build();

        // Create session factory and open session
        SessionFactory factory = meta.getSessionFactoryBuilder().build();
        Session session = factory.openSession();
        Transaction t = session.beginTransaction();

        // Create Employee object
        Employee e1 = new Employee();
        e1.setId(1004);
        e1.setFirstname("Rahul");
        e1.setLastname("Bose");

        // Save Employee object
        session.save(e1);

        // Commit the transaction
        t.commit();

        System.out.println("Successfully saved");
        System.out.println(e1.getId());
        System.out.println(e1.getFirstname());
        System.out.println(e1.getLastname());

        // Close session and factory
        factory.close();
        session.close();
    }
}
