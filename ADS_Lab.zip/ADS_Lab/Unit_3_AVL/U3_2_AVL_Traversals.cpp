#include <iostream>
#include <stack>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    int height;

    Node(int val) {
        data = val;
        left = right = nullptr;
        height = 1;
    }
};

// AVL Utility Functions
int height(Node* n) {
    return n ? n->height : 0;
}

int getBalance(Node* n) {
    return n ? height(n->left) - height(n->right) : 0;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

Node* rightRotate(Node* y) {
    Node* x = y->left;
    Node* T2 = x->right;

    x->right = y;
    y->left = T2;

    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;

    return x;
}

Node* leftRotate(Node* x) {
    Node* y = x->right;
    Node* T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

Node* insert(Node* node, int key) {
    if (!node)
        return new Node(key);

    if (key < node->data)
        node->left = insert(node->left, key);
    else if (key > node->data)
        node->right = insert(node->right, key);
    else
        return node;

    node->height = 1 + max(height(node->left), height(node->right));
    int bf = getBalance(node);

    if (bf > 1 && key < node->left->data)
        return rightRotate(node);
    if (bf < -1 && key > node->right->data)
        return leftRotate(node);
    if (bf > 1 && key > node->left->data) {
        node->left = leftRotate(node->left);
        return rightRotate(node);
    }
    if (bf < -1 && key < node->right->data) {
        node->right = rightRotate(node->right);
        return leftRotate(node);
    }

    return node;
}

// Recursive Traversals
void inorderRecursive(Node* root) {
    if (!root) return;
    inorderRecursive(root->left);
    cout << root->data << " ";
    inorderRecursive(root->right);
}

void preorderRecursive(Node* root) {
    if (!root) return;
    cout << root->data << " ";
    preorderRecursive(root->left);
    preorderRecursive(root->right);
}

void postorderRecursive(Node* root) {
    if (!root) return;
    postorderRecursive(root->left);
    postorderRecursive(root->right);
    cout << root->data << " ";
}

// Non-Recursive Traversals
void inorderNonRecursive(Node* root) {
    stack<Node*> st;
    Node* curr = root;

    while (curr != nullptr || !st.empty()) {
        while (curr != nullptr) {
            st.push(curr);
            curr = curr->left;
        }
        curr = st.top(); st.pop();
        cout << curr->data << " ";
        curr = curr->right;
    }
}

void preorderNonRecursive(Node* root) {
    if (!root) return;
    stack<Node*> st;
    st.push(root);

    while (!st.empty()) {
        Node* node = st.top(); st.pop();
        cout << node->data << " ";

        if (node->right)
            st.push(node->right);
        if (node->left)
            st.push(node->left);
    }
}

void postorderNonRecursive(Node* root) {
    if (!root) return;
    stack<Node*> st1, st2;
    st1.push(root);

    while (!st1.empty()) {
        Node* node = st1.top(); st1.pop();
        st2.push(node);
        if (node->left)
            st1.push(node->left);
        if (node->right)
            st1.push(node->right);
    }

    while (!st2.empty()) {
        cout << st2.top()->data << " ";
        st2.pop();
    }
}

int main() {
    Node* root = nullptr;
    int n, val;
    cout << "Enter number of elements: ";
    cin >> n;
    cout << "Enter elements:\n";
    for (int i = 0; i < n; i++) {
        cin >> val;
        root = insert(root, val);
    }

    cout << "\nRecursive Traversals:\n";
    cout << "Inorder   : "; inorderRecursive(root); cout << endl;
    cout << "Preorder  : "; preorderRecursive(root); cout << endl;
    cout << "Postorder : "; postorderRecursive(root); cout << endl;

    cout << "\nNon-Recursive Traversals:\n";
    cout << "Inorder   : "; inorderNonRecursive(root); cout << endl;
    cout << "Preorder  : "; preorderNonRecursive(root); cout << endl;
    cout << "Postorder : "; postorderNonRecursive(root); cout << endl;

    return 0;
}
