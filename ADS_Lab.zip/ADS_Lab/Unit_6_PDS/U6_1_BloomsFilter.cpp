// 1. Implement a Bloom Filter to check membership of elements in a dataset.

#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Size of Bloom Filter
const int SIZE = 100;

// Bloom Filter bit array
vector<bool> bloomFilter(SIZE, false);

// Hash functions
int hash1(string s) {
    int hash = 0;
    for (char c : s) {
        hash = (hash * 31 + c) % SIZE;
    }
    return hash;
}

int hash2(string s) {
    int hash = 0;
    for (char c : s) {
        hash = (hash * 17 + c) % SIZE;
    }
    return hash;
}

int hash3(string s) {
    int hash = 0;
    for (char c : s) {
        hash = (hash * 13 + c) % SIZE;
    }
    return hash;
}

// Insert element into Bloom Filter
void insert(string s) {
    bloomFilter[hash1(s)] = true;
    bloomFilter[hash2(s)] = true;
    bloomFilter[hash3(s)] = true;
}

// Check membership
bool check(string s) {
    return bloomFilter[hash1(s)] &&
           bloomFilter[hash2(s)] &&
           bloomFilter[hash3(s)];
}

int main() {
    int n;
    string item;

    cout << "Enter number of items to insert: ";
    cin >> n;

    cout << "Enter " << n << " strings:\n";
    for (int i = 0; i < n; i++) {
        cin >> item;
        insert(item);
    }

    char choice;
    do {
        cout << "\nEnter item to check: ";
        cin >> item;

        if (check(item)) {
            cout << item << " may be present in the set (possible false positive).\n";
        } else {
            cout << item << " is definitely not present in the set.\n";
        }

        cout << "Check another? (y/n): ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    return 0;
}
