// 2. Simulate a Count-Min Sketch data structure and estimate the frequency of queried elements.

#include <iostream>
#include <vector>
#include <string>
using namespace std;

// Dimensions of Count-Min Sketch
const int ROWS = 3;
const int COLS = 50;

vector<vector<int>> cms(ROWS, vector<int>(COLS, 0));

// Simple hash functions
int hash1(string s) {
    int hash = 0;
    for (char c : s) hash = (hash * 31 + c) % COLS;
    return hash;
}

int hash2(string s) {
    int hash = 0;
    for (char c : s) hash = (hash * 17 + c) % COLS;
    return hash;
}

int hash3(string s) {
    int hash = 0;
    for (char c : s) hash = (hash * 13 + c) % COLS;
    return hash;
}

// Insert element into CMS
void insert(string s) {
    cms[0][hash1(s)]++;
    cms[1][hash2(s)]++;
    cms[2][hash3(s)]++;
}

// Estimate frequency
int estimate(string s) {
    int f1 = cms[0][hash1(s)];
    int f2 = cms[1][hash2(s)];
    int f3 = cms[2][hash3(s)];
    return min(f1, min(f2, f3));
}

int main() {
    int n;
    string item;

    cout << "Enter number of elements to insert: ";
    cin >> n;

    cout << "Enter " << n << " elements (strings):\n";
    for (int i = 0; i < n; i++) {
        cin >> item;
        insert(item);
    }

    char choice;
    do {
        cout << "\nEnter element to estimate frequency: ";
        cin >> item;
        cout << "Estimated frequency of '" << item << "' is: " << estimate(item) << endl;

        cout << "Check another? (y/n): ";
        cin >> choice;
    } while (choice == 'y' || choice == 'Y');

    return 0;
}
