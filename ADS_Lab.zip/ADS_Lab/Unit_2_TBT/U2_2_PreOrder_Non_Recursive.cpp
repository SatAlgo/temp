#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    bool rightThread;

    Node(int val) : data(val), left(nullptr), right(nullptr), rightThread(false) {}
};

// Function to perform non-recursive preorder traversal
void preorderTraversal(Node* root) {
    Node* current = root;

    while (current) {
        cout << current->data << " ";

        // If left child exists, move to it
        if (current->left) {
            current = current->left;
        } else {
            // Otherwise, follow threads to next node in preorder sequence
            while (current && current->rightThread) {
                current = current->right;
                if (current) cout << current->data << " ";
            }
            // Move to actual right child
            if (current) current = current->right;
        }
    }
}

// Insert function with threading
Node* insert(Node* root, int key) {
    if (!root) return new Node(key);

    Node* parent = nullptr;
    Node* current = root;

    while (current) {
        parent = current;
        if (key < current->data) {
            if (!current->left) break;
            current = current->left;
        } else {
            if (!current->right || current->rightThread) break;
            current = current->right;
        }
    }

    Node* newNode = new Node(key);

    if (key < parent->data) {
        parent->left = newNode;
    } else {
        newNode->right = parent->right;
        newNode->rightThread = true;
        parent->right = newNode;
        parent->rightThread = false;
    }

    return root;
}

int main() {
    Node* root = nullptr;
    int choice, key;

    do {
        cout << "\n1. Insert Element\n2. Preorder Traversal\n3. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter element to insert: ";
                cin >> key;
                root = insert(root, key);
                break;
            case 2:
                cout << "Preorder Traversal: ";
                preorderTraversal(root);
                cout << endl;
                break;
            case 3:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 3);

    return 0;
}
