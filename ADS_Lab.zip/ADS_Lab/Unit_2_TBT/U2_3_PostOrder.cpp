#include <iostream>
#include <stack>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    bool rightThread;

    Node(int val) : data(val), left(nullptr), right(nullptr), rightThread(false) {}
};

// Recursive postorder traversal
void recursivePostorder(Node* root) {
    if (!root) return;
    
    recursivePostorder(root->left);
    recursivePostorder(root->right);
    cout << root->data << " ";
}

// Non-recursive postorder traversal using a stack
void nonRecursivePostorder(Node* root) {
    stack<Node*> s1, s2;
    
    if (!root) return;
    s1.push(root);
    
    while (!s1.empty()) {
        Node* current = s1.top();
        s1.pop();
        s2.push(current);

        if (current->left) s1.push(current->left);
        if (!current->rightThread && current->right) s1.push(current->right);
    }
    
    while (!s2.empty()) {
        cout << s2.top()->data << " ";
        s2.pop();
    }
}

// Insert function with threading
Node* insert(Node* root, int key) {
    if (!root) return new Node(key);

    Node* parent = nullptr;
    Node* current = root;

    while (current) {
        parent = current;
        if (key < current->data) {
            if (!current->left) break;
            current = current->left;
        } else {
            if (!current->right || current->rightThread) break;
            current = current->right;
        }
    }

    Node* newNode = new Node(key);

    if (key < parent->data) {
        parent->left = newNode;
    } else {
        newNode->right = parent->right;
        newNode->rightThread = true;
        parent->right = newNode;
        parent->rightThread = false;
    }

    return root;
}

int main() {
    Node* root = nullptr;
    int choice, key;

    do {
        cout << "\n1. Insert Element\n2. Recursive Postorder Traversal\n3. Non-Recursive Postorder Traversal\n4. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter element to insert: ";
                cin >> key;
                root = insert(root, key);
                break;
            case 2:
                cout << "Recursive Postorder Traversal: ";
                recursivePostorder(root);
                cout << endl;
                break;
            case 3:
                cout << "Non-Recursive Postorder Traversal: ";
                nonRecursivePostorder(root);
                cout << endl;
                break;
            case 4:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 4);

    return 0;
}
