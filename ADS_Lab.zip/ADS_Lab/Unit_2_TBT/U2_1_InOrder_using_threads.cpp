// 1. Implement a Threaded Binary Tree and perform inorder traversal using threads.

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
    bool rightThread;

    Node(int val) : data(val), left(nullptr), right(nullptr), rightThread(false) {}
};

// Function to find the leftmost node
Node* leftmost(Node* root) {
    while (root && root->left) {
        root = root->left;
    }
    return root;
}

// Threaded inorder traversal
void inorderTraversal(Node* root) {
    Node* current = leftmost(root);
    
    while (current) {
        cout << current->data << " ";
        
        if (current->rightThread) {
            current = current->right;
        } else {
            current = leftmost(current->right);
        }
    }
}

// Insert function with threading
Node* insert(Node* root, int key) {
    if (!root) return new Node(key);

    Node* parent = nullptr;
    Node* current = root;

    while (current) {
        parent = current;
        if (key < current->data) {
            if (!current->left) break;
            current = current->left;
        } else {
            if (!current->right || current->rightThread) break;
            current = current->right;
        }
    }

    Node* newNode = new Node(key);

    if (key < parent->data) {
        parent->left = newNode;
    } else {
        newNode->right = parent->right;
        newNode->rightThread = true;
        parent->right = newNode;
        parent->rightThread = false;
    }

    return root;
}

int main() {
    Node* root = nullptr;
    int choice, key;

    do {
        cout << "\n1. Insert Element\n2. Inorder Traversal\n3. Exit\nEnter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter element to insert: ";
                cin >> key;
                root = insert(root, key);
                break;
            case 2:
                cout << "Inorder Traversal: ";
                inorderTraversal(root);
                cout << endl;
                break;
            case 3:
                cout << "Exiting...\n";
                break;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 3);

    return 0;
}