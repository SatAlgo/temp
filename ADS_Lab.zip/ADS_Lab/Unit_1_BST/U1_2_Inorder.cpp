// 2. Given a BST, implement both recursive and non-recursive inorder traversals.

#include <iostream>
#include <stack>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;
};

// Create a new node
Node* createNode(int value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Insert into BST
Node* insert(Node* root, int value) {
    if (root == NULL)
        return createNode(value);
    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);
    return root;
}

// Recursive Inorder Traversal
void recursiveInorder(Node* root) {
    if (root == NULL)
        return;
    recursiveInorder(root->left);
    cout << root->data << " ";
    recursiveInorder(root->right);
}

// Non-Recursive Inorder Traversal
void nonRecursiveInorder(Node* root) {
    stack<Node*> st;
    Node* current = root;

    while (current != NULL || !st.empty()) {
        while (current != NULL) {
            st.push(current);
            current = current->left;
        }
        current = st.top();
        st.pop();
        cout << current->data << " ";
        current = current->right;
    }
}

int main() {
    Node* root = NULL;
    int n, value;

    cout << "Enter number of nodes: ";
    cin >> n;

    cout << "Enter values:\n";
    for (int i = 0; i < n; i++) {
        cin >> value;
        root = insert(root, value);
    }

    cout << "Recursive Inorder Traversal: ";
    recursiveInorder(root);
    cout << "\n";

    cout << "Non-Recursive Inorder Traversal: ";
    nonRecursiveInorder(root);
    cout << "\n";

    return 0;
}
